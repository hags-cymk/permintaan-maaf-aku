# Permintaan Maaf ❤️

Website sederhana untuk menyampaikan permintaan maaf.

## Menjalankan di HP

Tidak membutuhkan Node.js atau npm. Cukup buka `index.html` di browser.

Jika ingin dipublikasikan:
1. Upload `index.html` ke GitHub.
2. Aktifkan **GitHub Pages** pada Settings → Pages.
3. Pilih branch `main` dan folder `/ (root)`.
4. Buka URL GitHub Pages yang diberikan GitHub.

## Catatan aset

Jika halaman meminta foto atau musik, tambahkan file aset yang direferensikan oleh HTML ke folder yang sama dengan `index.html`.
